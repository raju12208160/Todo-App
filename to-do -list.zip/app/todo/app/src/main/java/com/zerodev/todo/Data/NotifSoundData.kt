package com.zerodev.todo.Data

data class NotifSoundData(val title: String, val path: String)
