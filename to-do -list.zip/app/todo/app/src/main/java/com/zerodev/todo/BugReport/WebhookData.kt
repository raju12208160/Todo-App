package com.zerodev.todo.BugReport

data class WebhookData(val content: String)
